import SwiftUI
import UniformTypeIdentifiers
import QuickLook
import UIKit

@main
struct PocketUnzipApp: App {
    @StateObject private var model = UnzipModel()
    var body: some Scene {
        WindowGroup {
            HomeView().environmentObject(model).tint(Color(red: 0.15, green: 0.37, blue: 0.30))
                .onOpenURL { model.start($0) }
        }
    }
}

@MainActor
final class UnzipModel: ObservableObject {
    @Published var busy = false
    @Published var fraction = 0.0
    @Published var message = "選擇 ZIP，直接解壓到手機。"
    @Published var folders: [URL] = []
    @Published var zipFiles: [URL] = []
    @Published var error: String?
    private var cancellation: Progress?
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    let root = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("解壓檔案", isDirectory: true)
    let zipRoot = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("壓縮檔案", isDirectory: true)

    init() { refresh() }
    func refresh() {
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: zipRoot, withIntermediateDirectories: true)
        zipFiles = ((try? FileManager.default.contentsOfDirectory(at: zipRoot,
                    includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])) ?? [])
            .filter { $0.pathExtension.lowercased() == "zip" }
            .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
        folders = ((try? FileManager.default.contentsOfDirectory(at: root,
                    includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])) ?? [])
            .filter { (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true }
            .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
    }
    func cancel() { cancellation?.cancel() }
    func compress(_ urls: [URL], name: String) {
        guard !busy else { error = "請等待目前工作完成。"; return }
        do { _ = try ArchiveEngine.zipName(name) } catch { self.error = error.localizedDescription; return }
        guard !urls.isEmpty else { error = "請先選擇檔案或資料夾。"; return }
        busy = true; fraction = 0; message = "正在壓縮…"
        let progress = Progress(totalUnitCount: 1)
        cancellation = progress
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "Zip") { [weak self] in
            Task { @MainActor in self?.cancel() }
        }
        let destination = zipRoot
        Task {
            do {
                let result = try await Task.detached(priority: .userInitiated) {
                    try ArchiveEngine.compress(urls, name: name, into: destination, cancellation: progress) { value, file in
                        Task { @MainActor in
                            guard self.busy else { return }
                            self.fraction = value; self.message = file
                        }
                    }
                }.value
                fraction = 1; message = "已壓縮並儲存：\(result.lastPathComponent)"
                refresh()
            } catch {
                self.error = error.localizedDescription
                message = progress.isCancelled ? "已取消壓縮，暫存檔已清除。" : "壓縮失敗，來源檔案保持完整。"
            }
            busy = false; cancellation = nil
            if backgroundTask != .invalid { UIApplication.shared.endBackgroundTask(backgroundTask); backgroundTask = .invalid }
        }
    }
    func start(_ url: URL) {
        guard !busy else { error = "請先等待目前的解壓完成。"; return }
        guard url.pathExtension.lowercased() == "zip" else { error = "目前支援 ZIP；RAR、7Z 與密碼 ZIP 尚未支援。"; return }
        busy = true; fraction = 0; message = "正在讀取 ZIP…"
        let progress = Progress(totalUnitCount: 1)
        cancellation = progress
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "Unzip") { [weak self] in
            Task { @MainActor in self?.cancel() }
        }
        let root = self.root
        Task {
            do {
                let result = try await Task.detached(priority: .userInitiated) {
                    let accessed = url.startAccessingSecurityScopedResource()
                    defer { if accessed { url.stopAccessingSecurityScopedResource() } }
                    let coordinator = NSFileCoordinator()
                    var coordinationError: NSError?
                    var output: Result<URL, Error>?
                    coordinator.coordinate(readingItemAt: url, options: .withoutChanges, error: &coordinationError) { readable in
                        output = Result {
                            try ArchiveEngine.extract(readable, into: root, cancellation: progress) { value, file in
                                Task { @MainActor in
                                    guard self.busy else { return }
                                    self.fraction = value; self.message = file
                                }
                            }
                        }
                    }
                    if let coordinationError { throw coordinationError }
                    guard let output else { throw CocoaError(.fileReadUnknown) }
                    return try output.get()
                }.value
                fraction = 1
                message = "已儲存：\(result.lastPathComponent)"
                refresh()
            } catch {
                self.error = "\(error.localizedDescription)\n若為密碼 ZIP 或特殊壓縮格式，請改用未加密 ZIP。"
                message = progress.isCancelled ? "已取消，未完成檔案已清除。" : "解壓失敗，原始 ZIP 保持完整。"
            }
            busy = false; cancellation = nil
            if backgroundTask != .invalid { UIApplication.shared.endBackgroundTask(backgroundTask); backgroundTask = .invalid }
        }
    }
}

struct HomeView: View {
    @EnvironmentObject private var model: UnzipModel
    @State private var importing = false
    @State private var creatingZip = false
    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 16) {
                        Image(systemName: "doc.zipper").font(.system(size: 44)).foregroundStyle(.tint)
                        Text("壓縮、解壓縮，\n直接留在手機。 ").font(.largeTitle.bold())
                        Text("全程離線處理，不需登入。保留原本的資料夾結構。")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Button { importing = true } label: {
                            Label("選擇 ZIP 解壓縮", systemImage: "plus.circle.fill")
                                .frame(maxWidth: .infinity).padding(.vertical, 7)
                        }.buttonStyle(.borderedProminent).disabled(model.busy)
                        Button { creatingZip = true } label: {
                            Label("選擇檔案／資料夾壓縮", systemImage: "archivebox.fill")
                                .frame(maxWidth: .infinity).padding(.vertical, 7)
                        }.buttonStyle(.bordered).disabled(model.busy)
                        if model.busy {
                            ProgressView(value: model.fraction)
                            Button("取消目前工作", role: .cancel) { model.cancel() }
                        }
                        Text(model.message).font(.caption).foregroundStyle(.secondary).lineLimit(3)
                            .accessibilityIdentifier("unzipStatus")
                    }.padding(.vertical, 12)
                }
                if !model.zipFiles.isEmpty {
                    Section("壓縮完成的 ZIP") {
                        ForEach(model.zipFiles, id: \.self) { ZipOutputRow(url: $0) }
                    }
                }
                Section("已儲存到手機") {
                    if model.folders.isEmpty {
                        Label("解壓完成後，資料夾會顯示在這裡。", systemImage: "folder")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    ForEach(model.folders, id: \.self) { folder in
                        NavigationLink { FolderView(folder: folder) } label: {
                            Label(folder.lastPathComponent, systemImage: "folder.fill")
                        }
                    }
                }
                Section {
                    Text("也可從「檔案」App 分享 ZIP 給「解壓口袋」。解壓結果位於「檔案 → 我的 iPhone → 解壓口袋 → 解壓檔案」。")
                    Text("無 200 MB 上限；依手機可用容量處理。大量解壓時請保持 App 開啟。支援未加密 ZIP，不支援 RAR／7Z。")
                    Text("建立的 ZIP 會保存在「檔案 → 我的 iPhone → 解壓口袋 → 壓縮檔案」，也可另存至 iCloud 或分享。壓縮不會刪除來源；照片、影片原本已壓縮，ZIP 不一定會明顯變小。")
                }.font(.footnote).foregroundStyle(.secondary)
            }.navigationTitle("解壓口袋")
                .refreshable { model.refresh() }
                .sheet(isPresented: $creatingZip) { CreateZipView().environmentObject(model) }
                .fileImporter(isPresented: $importing, allowedContentTypes: [.zip], allowsMultipleSelection: false) { result in
                    switch result {
                    case .success(let urls): if let url = urls.first { model.start(url) }
                    case .failure(let error): model.error = error.localizedDescription
                    }
                }
                .alert("檔案處理提示", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
                    Button("確定") { model.error = nil }
                } message: { Text(model.error ?? "") }
        }
    }
}

struct CreateZipView: View {
    @EnvironmentObject private var model: UnzipModel
    @Environment(\.dismiss) private var dismiss
    @State private var urls: [URL] = []
    @State private var name = "封存"
    @State private var importing = false
    @State private var pickFolders = false
    @State private var failure: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("ZIP 名稱") {
                    TextField("例如：出攤照片", text: $name)
                    Text("自動加上 .zip；同名壓縮檔會另存新檔。").font(.caption).foregroundStyle(.secondary)
                }
                Section("來源") {
                    Button { pickFolders = false; importing = true } label: { Label("新增檔案（可多選）", systemImage: "doc.badge.plus") }
                    Button { pickFolders = true; importing = true } label: { Label("新增資料夾", systemImage: "folder.badge.plus") }
                    ForEach(urls, id: \.self) { url in Text(url.lastPathComponent) }
                        .onDelete { urls.remove(atOffsets: $0) }
                }
                Section {
                    Button {
                        do {
                            _ = try ArchiveEngine.zipName(name)
                            guard !urls.isEmpty else { throw ZipCreationFailure.emptySelection }
                            model.compress(urls, name: name)
                            dismiss()
                        } catch { failure = error.localizedDescription }
                    } label: { Label("開始壓縮", systemImage: "archivebox.fill").frame(maxWidth: .infinity) }
                        .disabled(urls.isEmpty || model.busy)
                    Text("保留資料夾結構、支援中文檔名。來源檔案不會被移動或刪除。大型壓縮請保持 App 開啟。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }.navigationTitle("壓縮成 ZIP")
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } } }
                .fileImporter(isPresented: $importing, allowedContentTypes: pickFolders ? [.folder] : [.item], allowsMultipleSelection: true) { result in
                    switch result {
                    case .success(let selected):
                        for url in selected where !urls.contains(url) { urls.append(url) }
                    case .failure(let error): failure = error.localizedDescription
                    }
                }
                .alert("壓縮提示", isPresented: Binding(get: { failure != nil }, set: { if !$0 { failure = nil } })) {
                    Button("確定") { failure = nil }
                } message: { Text(failure ?? "") }
        }
    }
}

struct ZipOutputRow: View {
    let url: URL
    @State private var exporting = false
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(url.lastPathComponent, systemImage: "doc.zipper").lineLimit(2)
            HStack {
                Button("儲存到檔案") { exporting = true }.buttonStyle(.bordered)
                ShareLink(item: url) { Label("分享", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered)
            }
        }.padding(.vertical, 4)
            .sheet(isPresented: $exporting) { FolderExporter(url: url) }
    }
}

struct FolderView: View {
    let folder: URL
    @State private var children: [URL] = []
    @State private var search = ""
    @State private var preview: URL?
    @State private var exporting = false
    @State private var failure: String?
    private func isDirectory(_ url: URL) -> Bool {
        (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true
    }
    var body: some View {
        List {
            if children.isEmpty { Text("資料夾是空的").foregroundStyle(.secondary) }
            ForEach(children.filter { search.isEmpty || $0.lastPathComponent.localizedCaseInsensitiveContains(search) }, id: \.self) { url in
                if isDirectory(url) {
                    NavigationLink { FolderView(folder: url) } label: {
                        Label(url.lastPathComponent, systemImage: "folder.fill")
                    }
                } else {
                    HStack {
                        Button { preview = url } label: {
                            Label(url.lastPathComponent, systemImage: "doc").lineLimit(2)
                        }.buttonStyle(.plain)
                        Spacer()
                        ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                            .accessibilityLabel("分享或儲存 \(url.lastPathComponent)")
                    }
                }
            }
        }.navigationTitle(folder.lastPathComponent).navigationBarTitleDisplayMode(.inline)
            .searchable(text: $search, prompt: "搜尋檔名")
            .toolbar { Button { exporting = true } label: { Label("匯出資料夾", systemImage: "folder.badge.plus") } }
            .task {
                do {
                    children = try FileManager.default.contentsOfDirectory(at: folder,
                        includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])
                        .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
                } catch { failure = error.localizedDescription }
            }
            .quickLookPreview($preview)
            .sheet(isPresented: $exporting) { FolderExporter(url: folder) }
            .alert("無法讀取或匯出", isPresented: Binding(get: { failure != nil }, set: { if !$0 { failure = nil } })) {
                Button("確定") { failure = nil }
            } message: { Text(failure ?? "") }
    }
}

struct FolderExporter: UIViewControllerRepresentable {
    let url: URL
    @Environment(\.dismiss) private var dismiss
    func makeCoordinator() -> Coordinator { Coordinator(onFinish: { dismiss() }) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let controller = UIDocumentPickerViewController(forExporting: [url], asCopy: true)
        controller.delegate = context.coordinator
        return controller
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onFinish: () -> Void
        init(onFinish: @escaping () -> Void) { self.onFinish = onFinish }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { onFinish() }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { onFinish() }
    }
}
