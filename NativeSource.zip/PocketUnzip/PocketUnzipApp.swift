import SwiftUI
import UniformTypeIdentifiers
import QuickLook
import UIKit

@main
struct PocketUnzipApp: App {
    @StateObject private var model = UnzipModel()
    var body: some Scene {
        WindowGroup {
            HomeView().environmentObject(model).tint(Color(red: 0.15, green: 0.37, blue: 0.30))
                .onOpenURL { model.start($0) }
        }
    }
}

@MainActor
final class UnzipModel: ObservableObject {
    @Published var busy = false
    @Published var fraction = 0.0
    @Published var message = "選擇 ZIP，直接解壓到手機。"
    @Published var folders: [URL] = []
    @Published var error: String?
    private var cancellation: Progress?
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    let root = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("解壓檔案", isDirectory: true)

    init() { refresh() }
    func refresh() {
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        folders = ((try? FileManager.default.contentsOfDirectory(at: root,
                    includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])) ?? [])
            .filter { (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true }
            .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
    }
    func cancel() { cancellation?.cancel() }
    func start(_ url: URL) {
        guard !busy else { error = "請先等待目前的解壓完成。"; return }
        guard url.pathExtension.lowercased() == "zip" else { error = "目前支援 ZIP；RAR、7Z 與密碼 ZIP 尚未支援。"; return }
        busy = true; fraction = 0; message = "正在讀取 ZIP…"
        let progress = Progress(totalUnitCount: 1)
        cancellation = progress
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "Unzip") { [weak self] in
            Task { @MainActor in self?.cancel() }
        }
        let root = self.root
        Task {
            do {
                let result = try await Task.detached(priority: .userInitiated) {
                    let accessed = url.startAccessingSecurityScopedResource()
                    defer { if accessed { url.stopAccessingSecurityScopedResource() } }
                    let coordinator = NSFileCoordinator()
                    var coordinationError: NSError?
                    var output: Result<URL, Error>?
                    coordinator.coordinate(readingItemAt: url, options: .withoutChanges, error: &coordinationError) { readable in
                        output = Result {
                            try ArchiveEngine.extract(readable, into: root, cancellation: progress) { value, file in
                                Task { @MainActor in
                                    guard self.busy else { return }
                                    self.fraction = value; self.message = file
                                }
                            }
                        }
                    }
                    if let coordinationError { throw coordinationError }
                    guard let output else { throw CocoaError(.fileReadUnknown) }
                    return try output.get()
                }.value
                fraction = 1
                message = "已儲存：\(result.lastPathComponent)"
                refresh()
            } catch {
                self.error = "\(error.localizedDescription)\n若為密碼 ZIP 或特殊壓縮格式，請改用未加密 ZIP。"
                message = progress.isCancelled ? "已取消，未完成檔案已清除。" : "解壓失敗，原始 ZIP 保持完整。"
            }
            busy = false; cancellation = nil
            if backgroundTask != .invalid { UIApplication.shared.endBackgroundTask(backgroundTask); backgroundTask = .invalid }
        }
    }
}

struct HomeView: View {
    @EnvironmentObject private var model: UnzipModel
    @State private var importing = false
    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 16) {
                        Image(systemName: "doc.zipper").font(.system(size: 44)).foregroundStyle(.tint)
                        Text("解開檔案，\n直接留在手機。 ").font(.largeTitle.bold())
                        Text("全程離線處理，不需登入。保留原本的資料夾結構。")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Button { importing = true } label: {
                            Label("選擇 ZIP 解壓縮", systemImage: "plus.circle.fill")
                                .frame(maxWidth: .infinity).padding(.vertical, 7)
                        }.buttonStyle(.borderedProminent).disabled(model.busy)
                        if model.busy {
                            ProgressView(value: model.fraction)
                            Button("取消解壓", role: .cancel) { model.cancel() }
                        }
                        Text(model.message).font(.caption).foregroundStyle(.secondary).lineLimit(3)
                            .accessibilityIdentifier("unzipStatus")
                    }.padding(.vertical, 12)
                }
                Section("已儲存到手機") {
                    if model.folders.isEmpty {
                        Label("解壓完成後，資料夾會顯示在這裡。", systemImage: "folder")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    ForEach(model.folders, id: \.self) { folder in
                        NavigationLink { FolderView(folder: folder) } label: {
                            Label(folder.lastPathComponent, systemImage: "folder.fill")
                        }
                    }
                }
                Section {
                    Text("也可從「檔案」App 分享 ZIP 給「解壓口袋」。解壓結果位於「檔案 → 我的 iPhone → 解壓口袋 → 解壓檔案」。")
                    Text("無 200 MB 上限；依手機可用容量處理。大量解壓時請保持 App 開啟。支援未加密 ZIP，不支援 RAR／7Z。")
                }.font(.footnote).foregroundStyle(.secondary)
            }.navigationTitle("解壓口袋")
                .refreshable { model.refresh() }
                .fileImporter(isPresented: $importing, allowedContentTypes: [.zip], allowsMultipleSelection: false) { result in
                    switch result {
                    case .success(let urls): if let url = urls.first { model.start(url) }
                    case .failure(let error): model.error = error.localizedDescription
                    }
                }
                .alert("解壓提示", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
                    Button("確定") { model.error = nil }
                } message: { Text(model.error ?? "") }
        }
    }
}

struct FolderView: View {
    let folder: URL
    @State private var children: [URL] = []
    @State private var search = ""
    @State private var preview: URL?
    @State private var exporting = false
    @State private var failure: String?
    private func isDirectory(_ url: URL) -> Bool {
        (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true
    }
    var body: some View {
        List {
            if children.isEmpty { Text("資料夾是空的").foregroundStyle(.secondary) }
            ForEach(children.filter { search.isEmpty || $0.lastPathComponent.localizedCaseInsensitiveContains(search) }, id: \.self) { url in
                if isDirectory(url) {
                    NavigationLink { FolderView(folder: url) } label: {
                        Label(url.lastPathComponent, systemImage: "folder.fill")
                    }
                } else {
                    HStack {
                        Button { preview = url } label: {
                            Label(url.lastPathComponent, systemImage: "doc").lineLimit(2)
                        }.buttonStyle(.plain)
                        Spacer()
                        ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                            .accessibilityLabel("分享或儲存 \(url.lastPathComponent)")
                    }
                }
            }
        }.navigationTitle(folder.lastPathComponent).navigationBarTitleDisplayMode(.inline)
            .searchable(text: $search, prompt: "搜尋檔名")
            .toolbar { Button { exporting = true } label: { Label("匯出資料夾", systemImage: "folder.badge.plus") } }
            .task {
                do {
                    children = try FileManager.default.contentsOfDirectory(at: folder,
                        includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])
                        .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
                } catch { failure = error.localizedDescription }
            }
            .quickLookPreview($preview)
            .sheet(isPresented: $exporting) { FolderExporter(url: folder) }
            .alert("無法讀取或匯出", isPresented: Binding(get: { failure != nil }, set: { if !$0 { failure = nil } })) {
                Button("確定") { failure = nil }
            } message: { Text(failure ?? "") }
    }
}

struct FolderExporter: UIViewControllerRepresentable {
    let url: URL
    @Environment(\.dismiss) private var dismiss
    func makeCoordinator() -> Coordinator { Coordinator(onFinish: { dismiss() }) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let controller = UIDocumentPickerViewController(forExporting: [url], asCopy: true)
        controller.delegate = context.coordinator
        return controller
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onFinish: () -> Void
        init(onFinish: @escaping () -> Void) { self.onFinish = onFinish }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { onFinish() }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { onFinish() }
    }
}
