import Foundation
import ZIPFoundation

enum UnzipFailure: LocalizedError {
    case unsafePath, symbolicLink, insufficientSpace, tooManyFiles, sizeOverflow, badChecksum, cancelled, invalidSize
    var errorDescription: String? {
        switch self {
        case .unsafePath: return "ZIP 含有不安全或重複的檔案路徑。"
        case .symbolicLink: return "此 ZIP 含有符號連結，為避免寫入錯誤位置，已停止解壓。"
        case .insufficientSpace: return "手機可用空間不足，請清出空間後重試。"
        case .tooManyFiles: return "ZIP 超過 100,000 個項目，請分批解壓。"
        case .sizeOverflow: return "ZIP 宣告的檔案大小無效。"
        case .badChecksum: return "檔案校驗失敗，ZIP 可能已損壞，請重新下載。"
        case .cancelled: return "已取消解壓，未完成的檔案已清除。"
        case .invalidSize: return "解壓資料與 ZIP 宣告大小不一致，已停止處理。"
        }
    }
}

enum ArchiveEngine {
    static func safeDestination(_ path: String, in root: URL) throws -> URL {
        let components = path.split(separator: "/", omittingEmptySubsequences: true)
        guard !path.isEmpty, !path.hasPrefix("/"), !path.contains("\\"), !path.contains("\0"),
              !components.contains(".."), !components.contains("."), !components.isEmpty else { throw UnzipFailure.unsafePath }
        let result = root.appendingPathComponent(path).standardizedFileURL
        guard result.path.hasPrefix(root.standardizedFileURL.path + "/") else { throw UnzipFailure.unsafePath }
        return result
    }

    // Entire archive and expanded files are never held in memory. Each file is written in 64 KB chunks.
    static func extract(_ input: URL, into library: URL, cancellation: Progress,
                        update: @escaping (Double, String) -> Void) throws -> URL {
        let fm = FileManager.default
        try fm.createDirectory(at: library, withIntermediateDirectories: true)
        let archive = try Archive(url: input, accessMode: .read)
        let staging = library.appendingPathComponent(".unpacking-" + UUID().uuidString, isDirectory: true)
        try fm.createDirectory(at: staging, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: staging) }
        var total: UInt64 = 0, count = 0
        var seen = Set<String>()
        for entry in archive {
            if cancellation.isCancelled { throw UnzipFailure.cancelled }
            count += 1
            guard count <= 100_000 else { throw UnzipFailure.tooManyFiles }
            let target = try safeDestination(entry.path, in: staging)
            guard entry.type != .symlink else { throw UnzipFailure.symbolicLink }
            // iOS volumes may be case insensitive. Refuse ambiguous Unicode/case collisions.
            let key = target.path.precomposedStringWithCanonicalMapping.lowercased()
            guard seen.insert(key).inserted else { throw UnzipFailure.unsafePath }
            let sum = total.addingReportingOverflow(entry.uncompressedSize)
            guard !sum.overflow else { throw UnzipFailure.sizeOverflow }
            total = sum.partialValue
        }
        let capacity = try library.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        if let free = capacity.volumeAvailableCapacityForImportantUsage {
            let required = total.addingReportingOverflow(64 * 1024 * 1024)
            guard !required.overflow, free >= 0, UInt64(free) >= required.partialValue else { throw UnzipFailure.insufficientSpace }
        }
        var completed: UInt64 = 0
        var lastReport = Date.distantPast
        for entry in archive {
            if cancellation.isCancelled { throw UnzipFailure.cancelled }
            let target = try safeDestination(entry.path, in: staging)
            if entry.type == .directory {
                try fm.createDirectory(at: target, withIntermediateDirectories: true)
                continue
            }
            try fm.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
            guard fm.createFile(atPath: target.path, contents: nil) else { throw CocoaError(.fileWriteUnknown) }
            let handle = try FileHandle(forWritingTo: target)
            do {
                var written: UInt64 = 0
                let checksum = try archive.extract(entry, bufferSize: 64 * 1024, skipCRC32: false) { data in
                    if cancellation.isCancelled { throw UnzipFailure.cancelled }
                    let sum = written.addingReportingOverflow(UInt64(data.count))
                    guard !sum.overflow, sum.partialValue <= entry.uncompressedSize else { throw UnzipFailure.invalidSize }
                    try handle.write(contentsOf: data)
                    written = sum.partialValue
                    if Date().timeIntervalSince(lastReport) > 0.15 {
                        update(total == 0 ? 0 : Double(completed + written) / Double(total), entry.path)
                        lastReport = Date()
                    }
                }
                guard written == entry.uncompressedSize else { throw UnzipFailure.invalidSize }
                guard checksum == entry.checksum else { throw UnzipFailure.badChecksum }
                try handle.close()
            } catch { try? handle.close(); throw error }
            completed += entry.uncompressedSize
        }
        if cancellation.isCancelled { throw UnzipFailure.cancelled }
        var name = input.deletingPathExtension().lastPathComponent
        if name.isEmpty || name.hasPrefix(".") { name = "解壓檔案" }
        var destination = library.appendingPathComponent(name, isDirectory: true)
        var suffix = 2
        while fm.fileExists(atPath: destination.path) {
            destination = library.appendingPathComponent(name + " (\(suffix))", isDirectory: true)
            suffix += 1
        }
        try fm.moveItem(at: staging, to: destination)
        update(1, "解壓完成")
        return destination
    }
}
