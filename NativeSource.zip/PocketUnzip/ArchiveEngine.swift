import Foundation
import ZIPFoundation

enum UnzipFailure: LocalizedError {
    case unsafePath, symbolicLink, insufficientSpace, tooManyFiles, sizeOverflow, badChecksum, cancelled, invalidSize
    var errorDescription: String? {
        switch self {
        case .unsafePath: return "ZIP 含有不安全或重複的檔案路徑。"
        case .symbolicLink: return "此 ZIP 含有符號連結，為避免寫入錯誤位置，已停止解壓。"
        case .insufficientSpace: return "手機可用空間不足，請清出空間後重試。"
        case .tooManyFiles: return "ZIP 超過 100,000 個項目，請分批解壓。"
        case .sizeOverflow: return "ZIP 宣告的檔案大小無效。"
        case .badChecksum: return "檔案校驗失敗，ZIP 可能已損壞，請重新下載。"
        case .cancelled: return "已取消解壓，未完成的檔案已清除。"
        case .invalidSize: return "解壓資料與 ZIP 宣告大小不一致，已停止處理。"
        }
    }
}

enum ArchiveEngine {
    /// Creates a ZIP directly on disk. Source files are read in 64 KB chunks.
    static func compress(_ inputs: [URL], name: String, into library: URL, cancellation: Progress,
                         update: @escaping (Double, String) -> Void) throws -> URL {
        guard !inputs.isEmpty else { throw ZipCreationFailure.emptySelection }
        let fm = FileManager.default
        let sources = Array(Set(inputs.map { $0.standardizedFileURL })).sorted { $0.path < $1.path }
        let accessed = sources.filter { $0.startAccessingSecurityScopedResource() }
        defer { accessed.forEach { $0.stopAccessingSecurityScopedResource() } }
        let name = try zipName(name)
        try fm.createDirectory(at: library, withIntermediateDirectories: true)
        let staging = library.appendingPathComponent(".creating-" + UUID().uuidString + ".zip")
        defer { try? fm.removeItem(at: staging) }
        var usedNames = Set<String>()
        do {
            // Closing the archive before moving it also flushes the central directory.
            let archive = try Archive(url: staging, accessMode: .create)
            for (index, source) in sources.enumerated() {
                if cancellation.isCancelled { throw UnzipFailure.cancelled }
                let coordinator = NSFileCoordinator()
                var coordinationError: NSError?, failure: Error?
                coordinator.coordinate(readingItemAt: source, options: .withoutChanges, error: &coordinationError) { readable in
                    do {
                        let values = try readable.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                        guard values.isSymbolicLink != true else { throw ZipCreationFailure.unsupportedSource }
                        let canonicalSource = readable.resolvingSymlinksInPath().standardizedFileURL.path
                        let canonicalOutput = library.resolvingSymlinksInPath().standardizedFileURL.path
                        if values.isDirectory == true && (canonicalSource == canonicalOutput || canonicalOutput.hasPrefix(canonicalSource + "/")) {
                            throw ZipCreationFailure.outputInsideSource
                        }
                        let original = source.lastPathComponent
                        guard !original.isEmpty, original != ".", original != "..", !original.contains("\\") else { throw ZipCreationFailure.unsupportedSource }
                        var topName = original, suffix = 2
                        while !usedNames.insert(topName.precomposedStringWithCanonicalMapping.lowercased()).inserted {
                            let ext = (original as NSString).pathExtension
                            let stem = ext.isEmpty || values.isDirectory == true ? original : (original as NSString).deletingPathExtension
                            topName = "\(stem) (\(suffix))" + (ext.isEmpty || values.isDirectory == true ? "" : "." + ext)
                            suffix += 1
                        }
                        struct Item { let url: URL; let path: String; let directory: Bool; let size: Int64 }
                        var items: [Item] = []
                        func collect(_ url: URL, path: String) throws {
                            if cancellation.isCancelled { throw UnzipFailure.cancelled }
                            guard items.count < 100_000 else { throw UnzipFailure.tooManyFiles }
                            _ = try safeDestination(path, in: library)
                            let v = try url.resourceValues(forKeys: [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
                            guard v.isSymbolicLink != true, v.isDirectory == true || v.isRegularFile == true else { throw ZipCreationFailure.unsupportedSource }
                            let directory = v.isDirectory == true
                            items.append(Item(url: url, path: path, directory: directory, size: directory ? 0 : Int64(v.fileSize ?? 0)))
                            if directory {
                                for child in try fm.contentsOfDirectory(at: url, includingPropertiesForKeys: nil).sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
                                    try collect(child, path: path + "/" + child.lastPathComponent)
                                }
                            }
                        }
                        try collect(readable, path: topName)
                        var total: Int64 = 0
                        for item in items {
                            let sum = total.addingReportingOverflow(item.size)
                            guard item.size >= 0, !sum.overflow else { throw UnzipFailure.sizeOverflow }
                            total = sum.partialValue
                        }
                        var completed: Int64 = 0
                        var lastReport = Date.distantPast
                        for item in items {
                            if cancellation.isCancelled { throw UnzipFailure.cancelled }
                            if item.directory {
                                try archive.addEntry(with: item.path + "/", type: .directory, uncompressedSize: Int64(0)) { _, _ in Data() }
                            } else {
                                let handle = try FileHandle(forReadingFrom: item.url)
                                do {
                                    try archive.addEntry(with: item.path, type: .file, uncompressedSize: item.size,
                                                         compressionMethod: .deflate, bufferSize: 64 * 1024) { position, count in
                                        if cancellation.isCancelled { throw UnzipFailure.cancelled }
                                        try handle.seek(toOffset: UInt64(position))
                                        let data = try handle.read(upToCount: count) ?? Data()
                                        guard data.count == count else { throw CocoaError(.fileReadUnknown) }
                                        if Date().timeIntervalSince(lastReport) > 0.15 {
                                            let local = total == 0 ? 0 : Double(completed + position + Int64(data.count)) / Double(total)
                                            update((Double(index) + local) / Double(sources.count), item.path)
                                            lastReport = Date()
                                        }
                                        return data
                                    }
                                    try handle.close()
                                } catch { try? handle.close(); throw error }
                                completed += item.size
                            }
                        }
                        update(Double(index + 1) / Double(sources.count), topName)
                    } catch { failure = error }
                }
                if let coordinationError { throw coordinationError }
                if let failure { throw failure }
            }
        }
        if cancellation.isCancelled { throw UnzipFailure.cancelled }
        var destination = library.appendingPathComponent(name + ".zip"), suffix = 2
        while fm.fileExists(atPath: destination.path) {
            destination = library.appendingPathComponent("\(name) (\(suffix)).zip")
            suffix += 1
        }
        try fm.moveItem(at: staging, to: destination)
        update(1, "壓縮完成")
        return destination
    }

    static func zipName(_ raw: String) throws -> String {
        var name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.lowercased().hasSuffix(".zip") { name = String(name.dropLast(4)) }
        guard !name.isEmpty, !name.hasPrefix("."), name.count <= 80,
              name.rangeOfCharacter(from: CharacterSet(charactersIn: "/\\:\0").union(.controlCharacters)) == nil else {
            throw ZipCreationFailure.invalidName
        }
        return name
    }

    static func safeDestination(_ path: String, in root: URL) throws -> URL {
        let components = path.split(separator: "/", omittingEmptySubsequences: true)
        guard !path.isEmpty, !path.hasPrefix("/"), !path.contains("\\"), !path.contains("\0"),
              !components.contains(".."), !components.contains("."), !components.isEmpty else { throw UnzipFailure.unsafePath }
        let result = root.appendingPathComponent(path).standardizedFileURL
        guard result.path.hasPrefix(root.standardizedFileURL.path + "/") else { throw UnzipFailure.unsafePath }
        return result
    }

    // Entire archive and expanded files are never held in memory. Each file is written in 64 KB chunks.
    static func extract(_ input: URL, into library: URL, cancellation: Progress,
                        update: @escaping (Double, String) -> Void) throws -> URL {
        let fm = FileManager.default
        try fm.createDirectory(at: library, withIntermediateDirectories: true)
        let archive = try Archive(url: input, accessMode: .read)
        let staging = library.appendingPathComponent(".unpacking-" + UUID().uuidString, isDirectory: true)
        try fm.createDirectory(at: staging, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: staging) }
        var total: UInt64 = 0, count = 0
        var seen = Set<String>()
        for entry in archive {
            if cancellation.isCancelled { throw UnzipFailure.cancelled }
            count += 1
            guard count <= 100_000 else { throw UnzipFailure.tooManyFiles }
            let target = try safeDestination(entry.path, in: staging)
            guard entry.type != .symlink else { throw UnzipFailure.symbolicLink }
            // iOS volumes may be case insensitive. Refuse ambiguous Unicode/case collisions.
            let key = target.path.precomposedStringWithCanonicalMapping.lowercased()
            guard seen.insert(key).inserted else { throw UnzipFailure.unsafePath }
            let sum = total.addingReportingOverflow(entry.uncompressedSize)
            guard !sum.overflow else { throw UnzipFailure.sizeOverflow }
            total = sum.partialValue
        }
        let capacity = try library.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        if let free = capacity.volumeAvailableCapacityForImportantUsage {
            let required = total.addingReportingOverflow(64 * 1024 * 1024)
            guard !required.overflow, free >= 0, UInt64(free) >= required.partialValue else { throw UnzipFailure.insufficientSpace }
        }
        var completed: UInt64 = 0
        var lastReport = Date.distantPast
        for entry in archive {
            if cancellation.isCancelled { throw UnzipFailure.cancelled }
            let target = try safeDestination(entry.path, in: staging)
            if entry.type == .directory {
                try fm.createDirectory(at: target, withIntermediateDirectories: true)
                continue
            }
            try fm.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
            guard fm.createFile(atPath: target.path, contents: nil) else { throw CocoaError(.fileWriteUnknown) }
            let handle = try FileHandle(forWritingTo: target)
            do {
                var written: UInt64 = 0
                let checksum = try archive.extract(entry, bufferSize: 64 * 1024, skipCRC32: false) { data in
                    if cancellation.isCancelled { throw UnzipFailure.cancelled }
                    let sum = written.addingReportingOverflow(UInt64(data.count))
                    guard !sum.overflow, sum.partialValue <= entry.uncompressedSize else { throw UnzipFailure.invalidSize }
                    try handle.write(contentsOf: data)
                    written = sum.partialValue
                    if Date().timeIntervalSince(lastReport) > 0.15 {
                        update(total == 0 ? 0 : Double(completed + written) / Double(total), entry.path)
                        lastReport = Date()
                    }
                }
                guard written == entry.uncompressedSize else { throw UnzipFailure.invalidSize }
                guard checksum == entry.checksum else { throw UnzipFailure.badChecksum }
                try handle.close()
            } catch { try? handle.close(); throw error }
            completed += entry.uncompressedSize
        }
        if cancellation.isCancelled { throw UnzipFailure.cancelled }
        var name = input.deletingPathExtension().lastPathComponent
        if name.isEmpty || name.hasPrefix(".") { name = "解壓檔案" }
        var destination = library.appendingPathComponent(name, isDirectory: true)
        var suffix = 2
        while fm.fileExists(atPath: destination.path) {
            destination = library.appendingPathComponent(name + " (\(suffix))", isDirectory: true)
            suffix += 1
        }
        try fm.moveItem(at: staging, to: destination)
        update(1, "解壓完成")
        return destination
    }
}

enum ZipCreationFailure: LocalizedError {
    case emptySelection, invalidName, unsupportedSource, outputInsideSource
    var errorDescription: String? {
        switch self {
        case .emptySelection: return "請先選擇要壓縮的檔案或資料夾。"
        case .invalidName: return "ZIP 名稱請填 1–80 個字，不可用點開頭或包含斜線、冒號與控制字元。"
        case .unsupportedSource: return "來源包含無法壓縮的特殊檔案或符號連結。"
        case .outputInsideSource: return "來源資料夾包含 App 的壓縮輸出位置，請改選要壓縮的子資料夾或檔案。"
        }
    }
}
