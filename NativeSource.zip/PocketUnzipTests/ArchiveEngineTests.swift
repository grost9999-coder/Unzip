import XCTest
@testable import PocketUnzip

final class ArchiveEngineTests: XCTestCase {
    func fixture(_ name: String) throws -> URL {
        try XCTUnwrap(Bundle(for: Self.self).url(forResource: name, withExtension: "zip"))
    }
    func temporary() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        addTeardownBlock { try? FileManager.default.removeItem(at: url) }
        return url
    }
    func testExpandsBeyondFormer200MBLimit() throws {
        let root = try temporary()
        let result = try ArchiveEngine.extract(fixture("large"), into: root,
            cancellation: Progress(totalUnitCount: 1)) { _, _ in }
        let size = try result.appendingPathComponent("large.bin").resourceValues(forKeys: [.fileSizeKey]).fileSize
        XCTAssertEqual(size, 201 * 1024 * 1024)
    }
    func testChinesePathsAndDuplicateArchiveNames() throws {
        let root = try temporary(), progress = Progress(totalUnitCount: 1)
        let input = try fixture("chinese")
        let first = try ArchiveEngine.extract(input, into: root, cancellation: progress) { _, _ in }
        let second = try ArchiveEngine.extract(input, into: root, cancellation: progress) { _, _ in }
        XCTAssertNotEqual(first, second)
        XCTAssertEqual(try String(contentsOf: first.appendingPathComponent("配方/測試.txt"), encoding: .utf8), "解壓成功")
    }
    func testRejectsTraversalAndCleansPartialFiles() throws {
        let root = try temporary()
        XCTAssertThrowsError(try ArchiveEngine.extract(fixture("traversal"), into: root,
            cancellation: Progress(totalUnitCount: 1)) { _, _ in })
        XCTAssertTrue(try FileManager.default.contentsOfDirectory(atPath: root.path).isEmpty)
    }
    func testRejectsCorruption() throws {
        let root = try temporary()
        XCTAssertThrowsError(try ArchiveEngine.extract(fixture("corrupt"), into: root,
            cancellation: Progress(totalUnitCount: 1)) { _, _ in })
        XCTAssertTrue(try FileManager.default.contentsOfDirectory(atPath: root.path).isEmpty)
    }
    func testCancellation() throws {
        let root = try temporary(), progress = Progress(totalUnitCount: 1)
        progress.cancel()
        XCTAssertThrowsError(try ArchiveEngine.extract(fixture("chinese"), into: root, cancellation: progress) { _, _ in })
        XCTAssertTrue(try FileManager.default.contentsOfDirectory(atPath: root.path).isEmpty)
    }
}
