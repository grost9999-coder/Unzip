import XCTest
@testable import PocketUnzip

final class ArchiveEngineTests: XCTestCase {
    func fixture(_ name: String) throws -> URL {
        try XCTUnwrap(Bundle(for: Self.self).url(forResource: name, withExtension: "zip"))
    }
    func temporary() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        addTeardownBlock { try? FileManager.default.removeItem(at: url) }
        return url
    }
    func testExpandsBeyondFormer200MBLimit() throws {
        let root = try temporary()
        let result = try ArchiveEngine.extract(fixture("large"), into: root,
            cancellation: Progress(totalUnitCount: 1)) { _, _ in }
        let size = try result.appendingPathComponent("large.bin").resourceValues(forKeys: [.fileSizeKey]).fileSize
        XCTAssertEqual(size, 201 * 1024 * 1024)
    }
    func testChinesePathsAndDuplicateArchiveNames() throws {
        let root = try temporary(), progress = Progress(totalUnitCount: 1)
        let input = try fixture("chinese")
        let first = try ArchiveEngine.extract(input, into: root, cancellation: progress) { _, _ in }
        let second = try ArchiveEngine.extract(input, into: root, cancellation: progress) { _, _ in }
        XCTAssertNotEqual(first, second)
        XCTAssertEqual(try String(contentsOf: first.appendingPathComponent("配方/測試.txt"), encoding: .utf8), "解壓成功")
    }
    func testRejectsTraversalAndCleansPartialFiles() throws {
        let root = try temporary()
        XCTAssertThrowsError(try ArchiveEngine.extract(fixture("traversal"), into: root,
            cancellation: Progress(totalUnitCount: 1)) { _, _ in })
        XCTAssertTrue(try FileManager.default.contentsOfDirectory(atPath: root.path).isEmpty)
    }
    func testRejectsCorruption() throws {
        let root = try temporary()
        XCTAssertThrowsError(try ArchiveEngine.extract(fixture("corrupt"), into: root,
            cancellation: Progress(totalUnitCount: 1)) { _, _ in })
        XCTAssertTrue(try FileManager.default.contentsOfDirectory(atPath: root.path).isEmpty)
    }
    func testCancellation() throws {
        let root = try temporary(), progress = Progress(totalUnitCount: 1)
        progress.cancel()
        XCTAssertThrowsError(try ArchiveEngine.extract(fixture("chinese"), into: root, cancellation: progress) { _, _ in })
        XCTAssertTrue(try FileManager.default.contentsOfDirectory(atPath: root.path).isEmpty)
    }
}

final class ZipCreationTests: XCTestCase {
    func temporary() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        addTeardownBlock { try? FileManager.default.removeItem(at: url) }
        return url
    }
    func testCompressionRoundTripIncludesUnicodeAndEmptyFolders() throws {
        let base = try temporary(), fm = FileManager.default
        let folder = base.appendingPathComponent("出攤資料")
        try fm.createDirectory(at: folder.appendingPathComponent("空資料夾"), withIntermediateDirectories: true)
        let expected = Data(String(repeating: "紅麴豆乳雞配方\n", count: 10000).utf8)
        try expected.write(to: folder.appendingPathComponent("配方.txt"))
        try Data().write(to: folder.appendingPathComponent("空檔案.txt"))
        let zip = try ArchiveEngine.compress([folder], name: "測試.zip", into: base.appendingPathComponent("zips"),
            cancellation: Progress(totalUnitCount: 1)) { _, _ in }
        XCTAssertEqual(zip.lastPathComponent, "測試.zip")
        let restored = try ArchiveEngine.extract(zip, into: base.appendingPathComponent("restored"),
            cancellation: Progress(totalUnitCount: 1)) { _, _ in }
        XCTAssertEqual(try Data(contentsOf: restored.appendingPathComponent("出攤資料/配方.txt")), expected)
        XCTAssertTrue(fm.fileExists(atPath: restored.appendingPathComponent("出攤資料/空資料夾").path))
        XCTAssertTrue(fm.fileExists(atPath: folder.appendingPathComponent("配方.txt").path))
        XCTAssertLessThan(try Data(contentsOf: zip).count, expected.count)
    }
    func testDuplicateNamesAndExistingOutputAreNotOverwritten() throws {
        let base = try temporary(), fm = FileManager.default
        let a = base.appendingPathComponent("a"), b = base.appendingPathComponent("b")
        try fm.createDirectory(at: a, withIntermediateDirectories: true)
        try fm.createDirectory(at: b, withIntermediateDirectories: true)
        let first = a.appendingPathComponent("photo.txt"), second = b.appendingPathComponent("photo.txt")
        try Data("first".utf8).write(to: first); try Data("second".utf8).write(to: second)
        let output = base.appendingPathComponent("output"), progress = Progress(totalUnitCount: 1)
        let zip1 = try ArchiveEngine.compress([first, second], name: "封存", into: output, cancellation: progress) { _, _ in }
        let zip2 = try ArchiveEngine.compress([first, second], name: "封存", into: output, cancellation: progress) { _, _ in }
        XCTAssertNotEqual(zip1, zip2)
        let restored = try ArchiveEngine.extract(zip1, into: base.appendingPathComponent("restored"), cancellation: progress) { _, _ in }
        let contents = try fm.contentsOfDirectory(at: restored, includingPropertiesForKeys: nil)
        XCTAssertEqual(contents.count, 2)
        XCTAssertEqual(Set(try contents.map { try String(contentsOf: $0, encoding: .utf8) }), Set(["first", "second"]))
    }
    func testCompressionCancellationCleansStaging() throws {
        let base = try temporary(), source = base.appendingPathComponent("source.txt")
        try Data("keep me".utf8).write(to: source)
        let progress = Progress(totalUnitCount: 1), output = base.appendingPathComponent("output")
        progress.cancel()
        XCTAssertThrowsError(try ArchiveEngine.compress([source], name: "取消", into: output, cancellation: progress) { _, _ in })
        XCTAssertTrue(try FileManager.default.contentsOfDirectory(atPath: output.path).isEmpty)
        XCTAssertTrue(FileManager.default.fileExists(atPath: source.path))
    }
    func testInvalidNameAndRecursiveOutputAreRejected() throws {
        XCTAssertThrowsError(try ArchiveEngine.zipName("../unsafe"))
        XCTAssertThrowsError(try ArchiveEngine.zipName(""))
        let base = try temporary()
        XCTAssertThrowsError(try ArchiveEngine.compress([base], name: "recursive", into: base.appendingPathComponent("output"),
            cancellation: Progress(totalUnitCount: 1)) { _, _ in })
    }
}
